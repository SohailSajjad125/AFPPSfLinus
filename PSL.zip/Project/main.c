// main.c
#include <stdio.h>
#include <stdlib.h>

void start_monitor();
char* predict_file();
void prefetch_file(const char *path);

int main() {
    int choice;

    while (1) {
        printf("\n===== Linux Prefetch Optimizer =====\n");
        printf("1. Start Monitoring File Access (Hybrid)\n");
        printf("2. Predict Most Accessed File\n");
        printf("3. Prefetch Predicted File\n");
        printf("4. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            int c; while ((c = getchar()) != '\n' && c != EOF);
            printf("Invalid input. Try again.\n");
            continue;
        }

        switch(choice) {
            case 1:
                start_monitor();
                break;
            case 2: {
                char *pred = predict_file();
                if (pred)
                    printf("[Prediction] Next likely file: %s\n", pred);
                else
                    printf("No data available.\n");
                break;
            }
            case 3: {
                char *pred = predict_file();
                if (pred)
                    prefetch_file(pred);
                else
                    printf("Nothing to prefetch.\n");
                break;
            }
            case 4:
                printf("Exiting program...\n");
                return 0;
            default:
                printf("Invalid choice. Enter 1-4.\n");
        }
    }
    return 0;
}
