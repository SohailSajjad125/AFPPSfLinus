// monitor.c (FINAL - ignores system GUI files & dedups)
#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

#define WATCH_DIR "/home/kali"
#define HISTORY_FILE "/tmp/history.log"
#define EVENT_BUF_LEN (1024 * (sizeof(struct inotify_event) + NAME_MAX + 1))
#define DEDUP_WINDOW_SEC 2

static volatile int keep_running = 1;
static int inotify_fd;
static FILE *log_file;

// Deduplication state
static char last_logged_path[PATH_MAX] = "";
static time_t last_logged_time = 0;

#define MAX_WATCHES 4096
struct { int wd; char path[PATH_MAX]; } watch_map[MAX_WATCHES];
int watch_count = 0;

void add_to_map(int wd, const char *path) {
    if (watch_count < MAX_WATCHES) {
        watch_map[watch_count].wd = wd;
        strncpy(watch_map[watch_count].path, path, PATH_MAX);
        watch_count++;
    }
}

const char* get_path_from_wd(int wd) {
    for (int i = 0; i < watch_count; i++) {
        if (watch_map[i].wd == wd) return watch_map[i].path;
    }
    return WATCH_DIR; // Fallback
}

/* Handle Ctrl+C cleanly */
void stop_monitor(int sig) {
    (void)sig;
    keep_running = 0;
    printf("\n[+] Stopping monitoring...\n");
}

/* Add inotify watch recursively - EXCLUDING hidden directories */
void add_watches(const char *dir) {
    char command[PATH_MAX + 64];
    // Use find to list directories but exclude any path containing a hidden component (/. matches /.)
    // Note: -path '*/.*' matches any path where a component starts with .
    snprintf(command, sizeof(command), "find '%s' -type d -not -path '*/.*' -print", dir);

    FILE *fp = popen(command, "r");
    if (!fp) {
        perror("popen failed");
        return;
    }

    char path[PATH_MAX];
    while (fgets(path, sizeof(path), fp)) {
        path[strcspn(path, "\n")] = 0; // remove newline
        if (strlen(path) == 0) continue;
        int wd = inotify_add_watch(inotify_fd, path, IN_OPEN);
        if (wd >= 0) {
            add_to_map(wd, path);
        }
    }
    pclose(fp);
}

/* Filter unwanted files */
int is_valid_file(const char *name) {
    if (!name || strlen(name) == 0) return 0;
    
    // 1. Hidden Files (starts with .)
    if (name[0] == '.') return 0;
    
    // 2. Backup Files (ends with ~)
    if (name[strlen(name) - 1] == '~') return 0;

    // 3. Specific System Noise Blocklist
    if (strstr(name, "recently-used.xbel")) return 0;
    if (strstr(name, ".Xauthority")) return 0;
    if (strstr(name, "accels.scm")) return 0;      // Ignore GTK accelerators
    
    // Note: Previously we blocked "user." and ".new", but this blocks valid files 
    // like "user.mp3" or "mysong.new.mp3". Since we exclude hidden directories,
    // we can safely allow these to ensure user content is logged.
    
    return 1;
}

void start_monitor() {
    signal(SIGINT, stop_monitor);

    // Create/clear history file
    log_file = fopen(HISTORY_FILE, "w");
    if (!log_file) {
        perror("Failed to create history file");
        return;
    }
    fclose(log_file);

    log_file = fopen(HISTORY_FILE, "a");
    if (!log_file) {
        perror("Failed to open history file");
        return;
    }

    inotify_fd = inotify_init1(IN_NONBLOCK);
    if (inotify_fd < 0) {
        perror("inotify_init failed");
        fclose(log_file);
        return;
    }

    add_watches(WATCH_DIR);

    printf("[+] Monitoring file access under %s (Execpt hidden dirs)\n", WATCH_DIR);
    printf("[+] Press CTRL+C to stop\n");

    char buffer[EVENT_BUF_LEN];

    while (keep_running) {
        int length = read(inotify_fd, buffer, EVENT_BUF_LEN);
        if (length < 0) {
            if (errno == EAGAIN || errno == EINTR) {
                usleep(100000); // 0.1s
                continue;
            }
            perror("read error");
            break;
        }

        int i = 0;
        time_t now = time(NULL);

        while (i < length) {
            struct inotify_event *event = (struct inotify_event *)&buffer[i];

            if (event->len > 0 && !(event->mask & IN_ISDIR)) {
                if (is_valid_file(event->name)) {
                    const char *dir = get_path_from_wd(event->wd);
                    char full_path[PATH_MAX * 2];
                    snprintf(full_path, sizeof(full_path), "%s/%s", dir, event->name);

                    // Deduplication check
                    int is_duplicate = 0;
                    if (strcmp(full_path, last_logged_path) == 0) {
                        if (difftime(now, last_logged_time) < DEDUP_WINDOW_SEC) {
                            is_duplicate = 1;
                        }
                    }

                    if (!is_duplicate) {
                        fprintf(log_file, "%s\n", full_path);
                        fflush(log_file);
                        printf("[LOGGED] %s\n", full_path);

                        // Update strict dedup state
                        snprintf(last_logged_path, sizeof(last_logged_path), "%.*s", (int)(sizeof(last_logged_path) - 1), full_path);
                        last_logged_path[sizeof(last_logged_path) - 1] = '\0'; // Ensure null termination
                        last_logged_time = now;
                    }
                }
            }

            i += sizeof(struct inotify_event) + event->len;
        }
    }

    fclose(log_file);
    close(inotify_fd);
    keep_running = 1;

    printf("[+] Returned to main menu.\n");
}
