// prefetch.c (FINAL)

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>

#define READAHEAD_SIZE (4 * 1024 * 1024)   // 4 MB

void prefetch_file(const char *path) {
    if (!path || strlen(path) == 0) {
        printf("No file to prefetch.\n");
        return;
    }

    struct stat st;
    if (stat(path, &st) < 0) {
        printf("[Error] stat failed for '%s': %s\n", path, strerror(errno));
        return;
    }

    if (!S_ISREG(st.st_mode)) {
        printf("[Skip] Not a regular file: %s\n", path);
        return;
    }

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        printf("[Error] Cannot open '%s': %s\n", path, strerror(errno));
        return;
    }

    printf("[+] Prefetching: %s\n", path);

    if (syscall(SYS_readahead, fd, 0, READAHEAD_SIZE) < 0) {
        printf("[Error] readahead failed: %s\n", strerror(errno));
    } else {
        printf("[OK] Prefetch completed (kernel cached data)\n");

        // Ask to open
        printf("Do you want to open the file? (y/n): ");
        char ch;
        // Consume any leftover newline
        while ((ch = getchar()) != '\n' && ch != EOF);
        scanf("%c", &ch);

        if (ch == 'y' || ch == 'Y') {
            char cmd[1024 + 16];
            snprintf(cmd, sizeof(cmd), "xdg-open '%s'", path);
            printf("[+] Opening with default application...\n");
            int ret = system(cmd);
            if (ret == -1) {
                printf("[Error] Failed to execute xdg-open\n");
            }
        }
    }

    close(fd);
}
