// predict.c (FINAL)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_FILES 2000
#define MAX_PATH 1024
#define HISTORY_FILE "/tmp/history.log"

char* predict_file() {
    static char best[MAX_PATH];
    char line[MAX_PATH];

    char files[MAX_FILES][MAX_PATH];
    int freq[MAX_FILES];
    int count = 0;

    FILE *log = fopen(HISTORY_FILE, "r");
    if (!log)
        return NULL;

    memset(freq, 0, sizeof(freq));

    while (fgets(line, sizeof(line), log)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) == 0) continue;

        int found = 0;
        for (int i = 0; i < count; i++) {
            if (strcmp(files[i], line) == 0) {
                freq[i]++;
                found = 1;
                break;
            }
        }

        if (!found && count < MAX_FILES) {
            strcpy(files[count], line);
            freq[count] = 1;
            count++;
        }
    }
    fclose(log);

    if (count == 0)
        return NULL;

    int max = 0;
    int index = 0;

    for (int i = 0; i < count; i++) {
        if (freq[i] > max) {
            max = freq[i];
            index = i;
        }
    }

    strcpy(best, files[index]);
    return best;
}
